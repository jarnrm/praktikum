# Apotek Sederhana

Aplikasi ini merupakan tugas mata kuliah pemrograman web semster IV, yang dibangun dengan framewaork CodeIgniter 3.1.xx

# Dashboard

![alt dashboard](https://i.ibb.co/pdWVYQb/das.png)

# Data Obat

![alt obat](https://i.ibb.co/tHmMV3v/ob.png)

# Transaksi Penjualan

![alt transaksi](https://i.ibb.co/bFyC9p4/tr.png)

# Server Requirements

PHP versi 5.6 atau diatasnya lebih di rekomedasikan.

# Cara Penginstalan

Letakkan file hasil downloadan / clone di folder htdocs (jika os windows), kemudian atur penamanan base_url di file config.php sesuaikan dengan nama folder yang dibuat di htdocs.

# Database

Silahkan buat database baru (namanya terserah), kemudia import file database-apotek-ci.sql,
lalu sesuaikan config databasenya.

# Login

Username = admin
Password = 123